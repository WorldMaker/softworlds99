// This locvar is used for when you upload your pages.  Just rename it
// to locvar.js on your server.  Again, you want to edit it just like
// the other locvar.js.

sitname = "SoftWorlds"
sitid = "sw"
sitsubid = "top"
baseadd = "http://sw.itgo.com"
homdress = "http://members.xoom.com/WrldMakr/index.html"
barlog = "http://sw.itgo.com/images/wm.gif"
sitlog = "http://sw.itgo.com/images/sw.gif"
